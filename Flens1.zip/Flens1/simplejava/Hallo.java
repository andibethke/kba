/**
 * 
 * @author andi_
 * @version 1.0
 * Bald ist Weihnachten
 */
public class Hallo{
/**
	 * kladfgf ask fhkjlda flkjadlfkjasljkf slkjasf lksj ff
	 * @param args Argumente
	 */
	public static void main(String[] args){
		System.out.println("Hallo KBA...");
	}
}