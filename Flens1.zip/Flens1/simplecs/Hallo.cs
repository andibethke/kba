public class Hallo{
	public static void Main(System.String[] args){
		System.Console.WriteLine("Hallo KBA...");
	}
}