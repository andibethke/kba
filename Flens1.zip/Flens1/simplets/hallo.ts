class Person {
    public name:string;

    sagHall(){
        console.log(`Hallo ${this.name}`);
    }
}

var andi=new Person();
andi.name="Andi";
andi.sagHall();