var Person = (function () {
    function Person() {
    }
    Person.prototype.sagHall = function () {
        console.log("Hallo " + this.name);
    };
    return Person;
})();
var andi = new Person();
andi.name = "Andi";
andi.sagHall();
