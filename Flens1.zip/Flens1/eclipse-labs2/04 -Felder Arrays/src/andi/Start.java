package andi;

import java.util.Arrays;



public class Start {

	public static void main(String[] args) {
		String[] names=new String[] 
				{"Johannes","Jeremias", "Kevin", "Simon","Tom",
				 "Finn","Vasily","Nicolas","Juri","Momme"};
		int[] feld=new int[] {5,9,130,1,17,44};
		
		sortiere(feld);
		Arrays.sort(names);
		
		for (int i : feld) {
			System.out.println(i);
		}
		
		for (String n : names) {
			System.out.println(n);
		}
		
		System.out.println(plus(222, 444));
		
	}
	
	static void sortiere(int[] x) {
		for (int o = 0; o < x.length; o++) {
			System.out.printf("%d. Durchlauf\r\n",o);
			for (int i = 0; i < x.length-1; i++) {
				if(x[i]>x[i+1]) {
					System.out.printf("Ich tausche %d mit %d\r\n", x[i],x[i+1]);
					int temp=x[i];
					x[i]=x[i+1];
					x[i+1]=temp;
				}
			}
			for (int i : x) {
				System.out.print(i+" ");
			} 
			System.out.println("");
		}
	}
	static int plus(int a, int b) {
		return a+b;
	}

}
