package de.kba.zr;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		int zufall=(int) (Math.random()*101);
		int anzahlVersuche=0;
		Scanner sc=new Scanner(System.in);
		
		while (true) {
			anzahlVersuche++;
			System.out.printf("%d. Versuch: ", anzahlVersuche);
			try {
				int eingabe=sc.nextInt();
				if (zufall<eingabe) {
					System.out.println("die gesuchte Zahl ist kleiner");
				}
				else if(zufall>eingabe){
					System.out.println("die gesuchte Zahl ist gr��er");
				}
				else {
					break; //beendet while
				}
			} catch (Exception e) {
				System.out.println("Alter!!!!!");
				sc.next();
			}
		} //end while
		System.out.println("Gl�ckwunsch, Digga...");
		

	}

}
