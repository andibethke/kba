package de.kba.gm;


import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Random;

public class GalgenratenSpiel {
	public String anzeige="", geheimesWort;
	public int anzahlFehler;
	
	public boolean istTot() {
		return anzahlFehler>10;
	}
	public boolean istGewonnen() {
		return anzeige.equals(geheimesWort);
	}
	
	public GalgenratenSpiel() throws Exception { //Wird automatisch aufgerufen
		var alleWoerter=Files.readAllLines(Paths.get("c:/temp/flens1/deutsch.txt"));
		var zufallszahlenGenerator=new Random();
		var zufallsZahl=zufallszahlenGenerator.nextInt(alleWoerter.size());
		
		geheimesWort=alleWoerter.get(zufallsZahl);
		
		for (int i = 0; i < geheimesWort.length(); i++) {
			anzeige+="-";
		}
		anzahlFehler=0;
	}
	
	public void eingabe(String zeichen) {
		String tmp="";
		boolean gefunden=false;
		String geheimeWortGROSS=geheimesWort.toUpperCase();
		String zeichenGROSS=zeichen.toUpperCase();
		for (int i = 0; i < geheimesWort.length(); i++) {
			if (geheimeWortGROSS.charAt(i)==zeichenGROSS.charAt(0)) {
				tmp+=geheimesWort.charAt(i);
				gefunden=true;
			}
			else {
				tmp+=anzeige.charAt(i);
			}
		}
		anzeige=tmp;
		if (!gefunden) {
			anzahlFehler++;
		}
	}
	
}
