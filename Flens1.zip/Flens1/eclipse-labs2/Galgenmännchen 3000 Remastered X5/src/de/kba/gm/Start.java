package de.kba.gm;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) throws Exception  {
		GalgenratenSpiel spiel=new GalgenratenSpiel();
		Scanner sc=new Scanner(System.in);
		
		while (true) {
			System.out.println(spiel.anzeige);
			System.out.printf("%d Fehler> ", spiel.anzahlFehler);
			spiel.eingabe(sc.next());
			if (spiel.istTot() || spiel.istGewonnen()) {
				break;
			}
		}
		if (spiel.istTot()) {
			System.out.println("Du bist tot, Alter -->"+spiel.geheimesWort);
		}
		else {
			System.out.println("GL�CKWUNSCH, Digga!");
		}
	}

}
