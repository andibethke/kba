package andi;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int z1, z2;
		//z1=100; z2=200;
		
		System.out.print("Zahl1: ");
		z1=sc.nextInt();
		System.out.print("Zahl2: ");
		z2=sc.nextInt();
		
		System.out.printf("Ergebnis: %d+%d=%d",z1,z2,z1+z2);

	}

}
