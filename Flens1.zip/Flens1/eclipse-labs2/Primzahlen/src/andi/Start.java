package andi;

public class Start {

	public static void main(String[] args) {
		int von=1, bis=20;
		
		for (int i = von; i <= bis; i++) {
			if(bistDuEinePrimzahl(i))
				System.out.println(i);
		}

	}

	private static boolean bistDuEinePrimzahl(int i) {
		if (i<2) {
			return false;
		}
		if(i==2) return true;
		
		for (int j = 2; j < i; j++) {
			System.out.printf("%d modulo %d = %d Rest %d\r\n",i,j,i/j,i%j);
			if(i % j == 0) {
				return false;
			}
		}
		return true;
	}

}
