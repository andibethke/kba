package andi;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Gebe so schnell wie m�glich das Alphabet ein!");
		long ms=System.currentTimeMillis();
		String eingabe=sc.next();
		
		if (eingabe.equals("abcdefghijklmnopqrstuvwxyz")) {
			System.out.printf("Zeit: %d s %d ms",
					(System.currentTimeMillis()-ms) / 1000,
					(System.currentTimeMillis()-ms) % 1000);
		}
		else {
			System.out.println("Alter!");
		}
		
		
		
	}

}
