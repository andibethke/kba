package andi;

public class Start {

	public static void main(String[] args) throws Exception {
		while (true) {
			for (int i = 0; i < 20; i++) {
					System.out.print("*");
					Thread.sleep(100);
			}
			
			for (int i = 20; i >0; i--) {
					System.out.print("\b");
					Thread.sleep(100);
			}
		}
	}

}
