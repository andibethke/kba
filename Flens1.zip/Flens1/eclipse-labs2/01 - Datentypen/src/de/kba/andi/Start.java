package de.kba.andi;

import java.time.LocalDateTime;

public class Start {

	//Hauptprogrammfunktion
	/*
	 * djskf hsdjkf sjdkf hsdjkf sjkdf hksdjf hskdfh sdkjf jskdfh 
	 * ds sdf sdklf jsdklf sjkldf jklsdfkj lsdklf 
	 */
	/**
	 * Hallo Digga...
	 * @param args
	 */
	public static void main(String[] args) {
		int i=333;
		//bin�re OPs
		i=i+2; i=i*2;  //670
		//un�re
		i++; i+=29;
		//logische OP > < >= <= == !=
		
		char c='a';
		String s="sdgfsdfsdfsdf";
		LocalDateTime jetzt=LocalDateTime.now();
		
		System.out.println(i);
		System.out.println(c++);
		System.out.println(c);
		System.out.println(jetzt);
		System.out.println(2!=3);
	}

}
