package andi;

import java.awt.Font;
import java.awt.GraphicsEnvironment;

public class Start {

	public static void main(String[] args) {
		int i=0;
		while (i<10) {
			System.out.println(i++);
		}
		
		do {
			System.out.println(--i);
		} while (i>0);
		for (int j = 1000; j < 1005; j++) {
			System.out.println(j);
			
		}
		for (String f : 
				GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
			if (f.length()>15 && f.startsWith("C") ) {
				System.out.println(f);
			}
			else {
				System.out.println(".");
			}
		}

	}

}
