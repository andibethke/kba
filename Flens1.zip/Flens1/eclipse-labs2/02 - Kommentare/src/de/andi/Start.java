package de.andi;
/**
 * 
 * @author andi_
 * @version 1.0
 * Bald ist Weihnachten
 */
public class Start {
	/**
	 * kladfgf ask fhkjlda flkjadlfkjasljkf slkjasf lksj ff
	 * @param args Argumente
	 */
	public static void main(String[] args) {
		
	}
}
