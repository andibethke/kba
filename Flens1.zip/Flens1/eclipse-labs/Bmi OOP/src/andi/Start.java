package andi;

public class Start {

	public static void main(String[] args) {

		Mensch andi=new Trainer();
		andi.gew=95;
		andi.gr=1.86;
		
		System.out.printf("Dein Bmi ist: %.2f (%s)\r\n",
				andi.getBmi(), andi.istOk());
		
		int h=0;
		while(!andi.istOk()) {
			andi.einStundeSporteln();
			h++;
		}
		System.out.printf("Nach %s Stunden Sport: Bmi: %.2f",
				h, andi.getBmi());
		
	}

}
class Mensch{
	public double gr, gew;
	
	public double getBmi() {
		return gew/(gr*gr);
	}
	public boolean istOk() {
		return getBmi()>19 && getBmi()<24;
	}
	public void einStundeSporteln() {
		gew-=.1;
	}
}
class Trainer extends Mensch{
	@Override
	public double getBmi() {
		return super.getBmi()*.8;
	}
}
