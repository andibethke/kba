package andi;

public class Start {

	public static void main(String[] args) {
		System.out.printf("Dein Bmi ist: %.2f (%s)", 
				getBmi(1.86, 80),
				istOk(getBmi(1.86, 80)));
	}
	
	static double getBmi(double gr, double gew) {
		return gew/(gr*gr);
	}
	
	static boolean istOk(double bmi) {
		return bmi>19 && bmi<24;
	}

}
