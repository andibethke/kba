package andi;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		var sc=new Scanner(System.in);
		int zufall=(int) (Math.random()*101);
		int  versuche=1;
		while (true) {
			System.out.printf("%d. Versuch: ", versuche++);
			int eingabe=sc.nextInt();
			if (zufall<eingabe) {
				System.out.println("keliner...");
			}
			else if (zufall>eingabe) {
				System.out.println("gr��er");
			}
			else {
				break;
			}
		}
		System.out.printf("Herlzichen Gl�ckwunsch (%d Versuche)", versuche);

	}

}
