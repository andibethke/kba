﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HbService.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HbService.Business.Tests
{
    [TestClass()]
    public class HaushaltsbuchTests
    {
        [TestMethod()]
        public void NeueTransaktionTest()
        {
            var hb = new Haushaltsbuch();
            hb.NeueTransaktion(new Transaktion() { Betrag = 100, IstHaben = true, Name = "Gehalt" });
            hb.NeueTransaktion(new Transaktion() { Betrag = 20, IstHaben = false, Name = "Flens" });
            hb.NeueTransaktion(new Transaktion() { Betrag = 1.5, IstHaben = false, Name = "Kaffee" });
            Assert.AreEqual(78.5, hb.Saldo);
        }
    }
}