﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HbService.Business
{
    public class Transaktion
    {
        public double Betrag { get; set; }
        public bool IstHaben { get; set; }
        public string Name { get; set; }
        public DateTime Wann { get; set; }
    }
}
