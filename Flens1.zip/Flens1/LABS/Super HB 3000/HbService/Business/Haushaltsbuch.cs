﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HbService.Business
{
    public class Haushaltsbuch
    {
        public Haushaltsbuch()
        {
            Transaktionens.Add(new Transaktion() { Name = "Willkommen", IstHaben = true, Betrag = 100 });
            Transaktionens.Add(new Transaktion() { Name = "Gebühr", IstHaben = false, Betrag = 25 });
        }
        public List<Transaktion> Transaktionens { get; set; } = new List<Transaktion>();

        public double Saldo => Transaktionens.Where(x => x.IstHaben).Sum(x => x.Betrag) -
                                Transaktionens.Where(x => !x.IstHaben).Sum(x => x.Betrag);

        public void NeueTransaktion(Transaktion t)
        {
            t.Wann = DateTime.Now;
            Transaktionens.Add(t);
        }

    }
}
