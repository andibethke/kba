﻿using HbService.Business;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HbService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HbController : ControllerBase
    {
        private static Business.Haushaltsbuch hb = new Business.Haushaltsbuch();
        [HttpGet]
        public IActionResult GetData()
        {
            return Ok(hb);
        }

        [HttpGet]
        
        public IActionResult PostData( double betrag, string istGuthaben=null, string name=null)
        {
            hb.NeueTransaktion(new Transaktion()
            { 
                Betrag=betrag,
                IstHaben=istGuthaben=="on",
                Name=name
            });
            return Ok();
        }
    }
}
