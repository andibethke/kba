public class Start{
	public static void main(String[] a){
		System.out.println("Hallo...");
		for(String s : a){
			System.out.println(s);
		}
	}
}